import numerical_methods.bissection, numerical_methods.euler, numerical_methods.gauss, numerical_methods.gauss_jacobi, \
    numerical_methods.gauss_seidel, numerical_methods.newton, numerical_methods.newton_2, numerical_methods.picard_peano, \
    numerical_methods.picard_peano_2, numerical_methods.runga_kutta_2, numerical_methods.runga_kutta_4, \
    numerical_methods.simpson, numerical_methods.trapezio
